# RedClient (Fabric 1.21.4)

Right Shift – open/close the menu. LMB toggles a module, RMB = set key bind (Backspace clears, Esc cancels).
Binds are saved to config/redclient.properties.

Build: push to GitHub -> Actions tab -> "build" -> download artifact "redclient-jar".
