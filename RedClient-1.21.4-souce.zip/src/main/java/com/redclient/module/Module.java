package com.redclient.module;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public final String id;
    public final String name;
    public boolean enabled;
    public int key = -1;
    boolean keyWasDown;

    protected Module(String id, String name) {
        this.id = id;
        this.name = name;
    }

    protected MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean v) {
        if (v == enabled) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }

    public void onEnable() { }
    public void onDisable() { }
    public void onTick() { }
}
