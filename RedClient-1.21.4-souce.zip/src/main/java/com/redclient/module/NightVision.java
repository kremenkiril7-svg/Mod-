package com.redclient.module;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class NightVision extends Module {
    public NightVision() { super("nightvision", "Ночное зрение"); }

    public static void apply(ClientPlayerEntity p) {
        StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 300) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false, false));
        }
    }

    public static void remove(ClientPlayerEntity p) {
        if (p != null) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }

    @Override
    public void onTick() { apply(mc().player); }

    @Override
    public void onDisable() { remove(mc().player); }
}
