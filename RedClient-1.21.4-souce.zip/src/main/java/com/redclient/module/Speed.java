package com.redclient.module;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    private static final double SPEED = 0.35; // blocks per tick (normal sprint is ~0.28)

    public Speed() { super("speed", "Скорость"); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (p.getAbilities().flying || p.isTouchingWater() || p.isInLava() || p.isClimbing()) return;
        GameOptions o = mc().options;
        float f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        float s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return;
        double yaw = Math.toRadians(p.getYaw());
        double dx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double dz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len == 0) return;
        dx /= len;
        dz /= len;
        Vec3d v = p.getVelocity();
        p.setVelocity(dx * SPEED, v.y, dz * SPEED);
    }
}
