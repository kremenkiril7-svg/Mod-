package com.redclient.module;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class XRay extends Module {
    public static volatile boolean active;
    private static final Map<Block, Boolean> CACHE = new ConcurrentHashMap<>();

    public XRay() { super("xray", "Рентген"); }

    public static boolean isOre(Block b) {
        return CACHE.computeIfAbsent(b, k -> {
            String path = Registries.BLOCK.getId(k).getPath();
            return path.endsWith("_ore") || path.equals("ancient_debris");
        });
    }

    private void reload() {
        MinecraftClient mc = mc();
        if (mc.worldRenderer != null && mc.world != null) mc.worldRenderer.reload();
    }

    @Override
    public void onEnable() {
        active = true;
        mc().chunkCullingEnabled = false;
        reload();
    }

    @Override
    public void onDisable() {
        active = false;
        mc().chunkCullingEnabled = true;
        if (ModuleManager.NIGHT == null || !ModuleManager.NIGHT.enabled) NightVision.remove(mc().player);
        reload();
    }

    @Override
    public void onTick() {
        NightVision.apply(mc().player); // fullbright so ores are visible in the dark
    }
}
