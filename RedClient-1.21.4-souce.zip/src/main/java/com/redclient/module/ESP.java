package com.redclient.module;

/** Red glow outline through walls on players (invisible ones too) and hostile mobs. See EntityMixin. */
public class ESP extends Module {
    public static volatile boolean active;

    public ESP() { super("esp", "Показ игроков/мобов (ESP)"); }

    @Override public void onEnable() { active = true; }
    @Override public void onDisable() { active = false; }
}
