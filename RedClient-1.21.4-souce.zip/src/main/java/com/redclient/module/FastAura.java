package com.redclient.module;

import com.redclient.Targets;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

/** Instant snap + attack every 2 ticks (about 10 CPS), ignores attack cooldown like in 1.8. */
public class FastAura extends Module {
    private int ticks;

    public FastAura() { super("fastaura", "Быстрая наводка+атака (1.8)"); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        ticks++;
        LivingEntity t = Targets.find(p, 5.0);
        if (t == null) return;
        float[] r = Targets.rotationTo(p, t);
        p.setYaw(r[0]);
        p.setPitch(MathHelper.clamp(r[1], -90f, 90f));
        if (ticks % 2 == 0) {
            mc().interactionManager.attackEntity(p, t);
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}
