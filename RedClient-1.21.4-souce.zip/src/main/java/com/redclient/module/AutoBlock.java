package com.redclient.module;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Places a block from the hotbar under your feet (bridge / scaffold). */
public class AutoBlock extends Module {
    public AutoBlock() { super("autoblock", "Авто-блок под собой"); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        ClientWorld w = mc().world;
        if (p.getAbilities().flying) return;

        BlockPos target = BlockPos.ofFloored(p.getX(), p.getY() - 1.0, p.getZ());
        if (!w.getBlockState(target).isReplaceable()) return;

        int slot = -1;
        int cur = p.getInventory().selectedSlot;
        if (isBlock(p.getInventory().getStack(cur))) {
            slot = cur;
        } else {
            for (int i = 0; i < 9; i++) {
                if (isBlock(p.getInventory().getStack(i))) { slot = i; break; }
            }
        }
        if (slot == -1) return;

        for (Direction d : Direction.values()) {
            BlockPos n = target.offset(d);
            if (w.getBlockState(n).isReplaceable()) continue;
            Direction side = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(n).add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
            p.getInventory().selectedSlot = slot;
            ActionResult res = mc().interactionManager.interactBlock(p, Hand.MAIN_HAND,
                    new BlockHitResult(hit, side, n, false));
            if (res.isAccepted()) p.swingHand(Hand.MAIN_HAND);
            return;
        }
    }

    private static boolean isBlock(ItemStack s) {
        return !s.isEmpty() && s.getItem() instanceof BlockItem;
    }
}
