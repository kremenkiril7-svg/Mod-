package com.redclient.module;

import net.minecraft.client.network.ClientPlayerEntity;

public class Fly extends Module {
    public Fly() { super("fly", "Полёт"); }

    @Override
    public void onEnable() {
        ClientPlayerEntity p = mc().player;
        if (p == null) return;
        p.getAbilities().allowFlying = true;
        p.getAbilities().flying = true;
        p.getAbilities().setFlySpeed(0.1f);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        p.getAbilities().allowFlying = true;
        p.getAbilities().setFlySpeed(0.1f);
    }

    @Override
    public void onDisable() {
        ClientPlayerEntity p = mc().player;
        if (p == null) return;
        p.getAbilities().setFlySpeed(0.05f);
        if (!p.isCreative() && !p.isSpectator()) {
            p.getAbilities().allowFlying = false;
            p.getAbilities().flying = false;
        }
    }
}
