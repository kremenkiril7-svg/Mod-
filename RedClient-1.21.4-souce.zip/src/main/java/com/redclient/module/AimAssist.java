package com.redclient.module;

import com.redclient.Targets;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;

public class AimAssist extends Module {
    public AimAssist() { super("aimassist", "Наводка + Авто-атака"); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        LivingEntity t = Targets.find(p, 4.5);
        if (t == null) return;
        float[] r = Targets.rotationTo(p, t);
        float dyaw = MathHelper.clamp(MathHelper.wrapDegrees(r[0] - p.getYaw()), -35f, 35f);
        float dpitch = MathHelper.clamp(r[1] - p.getPitch(), -35f, 35f);
        p.setYaw(p.getYaw() + dyaw);
        p.setPitch(MathHelper.clamp(p.getPitch() + dpitch, -90f, 90f));

        boolean onTarget = Math.abs(MathHelper.wrapDegrees(r[0] - p.getYaw())) < 6f
                && Math.abs(r[1] - p.getPitch()) < 6f;
        if (onTarget && p.getAttackCooldownProgress(0.5f) >= 1.0f) {
            mc().interactionManager.attackEntity(p, t);
            p.swingHand(Hand.MAIN_HAND);
        }
    }
}
