package com.redclient.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();
    public static NightVision NIGHT;

    public static void init() {
        MODULES.clear();
        MODULES.add(new AimAssist());
        MODULES.add(new FastAura());
        MODULES.add(new AutoBlock());
        MODULES.add(new Fly());
        MODULES.add(new XRay());
        NIGHT = new NightVision();
        MODULES.add(NIGHT);
        MODULES.add(new Speed());
        MODULES.add(new ESP());
    }

    public static void tick(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();
        for (Module m : MODULES) {
            if (m.key < 0) continue;
            boolean down = InputUtil.isKeyPressed(window, m.key);
            if (down && !m.keyWasDown && mc.currentScreen == null) m.toggle();
            m.keyWasDown = down;
        }
        for (Module m : MODULES) {
            if (m.enabled) m.onTick();
        }
    }
}
