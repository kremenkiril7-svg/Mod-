package com.redclient.ui;

import com.redclient.Config;
import com.redclient.RedClient;
import com.redclient.module.Module;
import com.redclient.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class MenuScreen extends Screen {
    private static final int W = 240, ROW = 22, GAP = 2, HEADER = 24;
    private Module binding;

    public MenuScreen() {
        super(Text.literal("RedClient"));
    }

    @Override
    public boolean shouldPause() { return false; }

    private int panelX() { return (width - W) / 2; }

    private int panelH() {
        return HEADER + 6 + ModuleManager.MODULES.size() * (ROW + GAP) + 20;
    }

    private int panelY() { return (height - panelH()) / 2; }

    private int rowY(int i) { return panelY() + HEADER + 6 + i * (ROW + GAP); }

    private boolean inRow(double mx, double my, int i) {
        int x = panelX() + 6;
        int y = rowY(i);
        return mx >= x && mx < x + W - 12 && my >= y && my < y + ROW;
    }

    private static String keyName(int k) {
        if (k < 0) return "-";
        return InputUtil.fromKeyCode(k, -1).getLocalizedText().getString();
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
        int x = panelX(), y = panelY(), h = panelH();

        ctx.fill(x - 3, y - 3, x + W + 3, y + h + 3, 0xFF5A0000);
        ctx.fill(x, y, x + W, y + h, 0xF0140000);
        ctx.fill(x, y, x + W, y + HEADER, 0xFFC00000);
        ctx.drawText(textRenderer, "RedClient", x + 8, y + 8, 0xFFFFFFFF, true);

        List<Module> list = ModuleManager.MODULES;
        for (int i = 0; i < list.size(); i++) {
            Module m = list.get(i);
            boolean hover = inRow(mx, my, i);
            int color;
            if (m.enabled) color = hover ? 0xFFFF2A2A : 0xFFD81010;
            else color = hover ? 0xFF6A1414 : 0xFF480A0A;
            int rx = x + 6, ry = rowY(i);
            ctx.fill(rx, ry, rx + W - 12, ry + ROW, color);
            ctx.drawText(textRenderer, m.name, rx + 6, ry + 7, 0xFFFFFFFF, true);
            String bind = binding == m ? "..." : "[" + keyName(m.key) + "]";
            int bw = textRenderer.getWidth(bind);
            ctx.drawText(textRenderer, bind, rx + W - 12 - bw - 6, ry + 7, 0xFFFFD0D0, true);
        }

        ctx.drawText(textRenderer, "ЛКМ вкл/выкл  ПКМ бинд  RShift закрыть",
                x + 8, y + h - 14, 0xFFB07070, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (binding != null) {
            binding = null;
            return true;
        }
        for (int i = 0; i < ModuleManager.MODULES.size(); i++) {
            if (inRow(mx, my, i)) {
                Module m = ModuleManager.MODULES.get(i);
                if (button == 0) m.toggle();
                else if (button == 1) binding = m;
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (binding != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                // cancel
            } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) {
                binding.key = -1;
                Config.save();
            } else {
                binding.key = keyCode;
                Config.save();
            }
            binding = null;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT || RedClient.menuKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
