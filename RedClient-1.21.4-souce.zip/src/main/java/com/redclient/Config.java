package com.redclient;

import com.redclient.module.Module;
import com.redclient.module.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class Config {
    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("redclient.properties");
    }

    public static void load() {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file())) {
            p.load(in);
        } catch (Exception e) {
            return;
        }
        for (Module m : ModuleManager.MODULES) {
            String v = p.getProperty(m.id);
            if (v != null) {
                try { m.key = Integer.parseInt(v.trim()); } catch (NumberFormatException ignored) { }
            }
        }
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : ModuleManager.MODULES) p.setProperty(m.id, String.valueOf(m.key));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "RedClient key binds (GLFW key codes, -1 = none)");
        } catch (Exception ignored) { }
    }
}
