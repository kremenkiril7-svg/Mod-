package com.redclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class Targets {
    /** Players (including invisible ones) and hostile mobs. */
    public static boolean isTarget(Entity e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (e == null || e == mc.player) return false;
        if (!(e instanceof LivingEntity le) || !le.isAlive()) return false;
        return e instanceof PlayerEntity || e instanceof Monster;
    }

    public static LivingEntity find(ClientPlayerEntity p, double range) {
        MinecraftClient mc = MinecraftClient.getInstance();
        LivingEntity best = null;
        double bestD = range * range;
        Vec3d eye = p.getEyePos();
        for (Entity e : mc.world.getEntities()) {
            if (!isTarget(e)) continue;
            LivingEntity le = (LivingEntity) e;
            double d = eye.squaredDistanceTo(le.getBoundingBox().getCenter());
            if (d < bestD && p.canSee(le)) {
                bestD = d;
                best = le;
            }
        }
        return best;
    }

    /** returns {yaw, pitch} needed to look at the target */
    public static float[] rotationTo(ClientPlayerEntity p, LivingEntity t) {
        Vec3d from = p.getEyePos();
        Vec3d to = t.getBoundingBox().getCenter();
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        return new float[]{yaw, pitch};
    }
}
