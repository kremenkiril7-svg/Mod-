package com.redclient.mixin;

import com.redclient.Targets;
import com.redclient.module.ESP;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void redclient$glow(CallbackInfoReturnable<Boolean> cir) {
        if (ESP.active && Targets.isTarget((Entity) (Object) this)) cir.setReturnValue(true);
    }

    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true)
    private void redclient$color(CallbackInfoReturnable<Integer> cir) {
        if (ESP.active && Targets.isTarget((Entity) (Object) this)) cir.setReturnValue(0xFF2020);
    }
}
