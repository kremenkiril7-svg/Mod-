package com.redclient.mixin;

import com.redclient.module.XRay;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Block.class)
public class BlockMixin {
    @Inject(method = "shouldDrawSide", at = @At("HEAD"), cancellable = true)
    private static void redclient$xray(BlockState state, BlockState otherState, Direction side,
                                       CallbackInfoReturnable<Boolean> cir) {
        if (XRay.active) cir.setReturnValue(XRay.isOre(state.getBlock()));
    }
}
